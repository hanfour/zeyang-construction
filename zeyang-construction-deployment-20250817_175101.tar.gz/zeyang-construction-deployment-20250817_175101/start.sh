#!/bin/bash

# 澤暘建設專案啟動腳本

set -e

echo "🚀 啟動澤暘建設專案..."

# 檢查 Node.js
if ! command -v node &> /dev/null; then
    echo "❌ Node.js 未安裝，請先安裝 Node.js 18+"
    exit 1
fi

# 檢查 npm
if ! command -v npm &> /dev/null; then
    echo "❌ npm 未安裝，請先安裝 npm"
    exit 1
fi

# 檢查環境配置
if [ ! -f "backend/.env" ]; then
    echo "⚠️  backend/.env 檔案不存在，請先配置環境變數"
    echo "參考 backend/.env.example 建立配置檔案"
    exit 1
fi

# 安裝後端依賴
echo "📦 安裝後端依賴..."
cd backend
if [ ! -d "node_modules" ]; then
    npm install --production
fi

# 檢查資料庫連接
echo "🔍 檢查資料庫連接..."
node -e "
const mysql = require('mysql2');
require('dotenv').config();
const connection = mysql.createConnection({
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
});
connection.connect((err) => {
  if (err) {
    console.error('❌ 資料庫連接失敗:', err.message);
    process.exit(1);
  }
  console.log('✅ 資料庫連接成功');
  connection.end();
});
"

# 啟動後端服務器
echo "🔥 啟動後端服務器..."
npm start &
BACKEND_PID=$!

cd ..

# 檢查是否有前端建置檔案
if [ -d "frontend/dist" ]; then
    echo "✅ 前端已建置，使用現有檔案"
else
    echo "🔨 建置前端..."
    cd frontend
    if [ ! -d "node_modules" ]; then
        npm install
    fi
    npm run build
    cd ..
fi

echo "✅ 澤暘建設專案啟動完成！"
echo "🌐 後端 API: http://localhost:5001"
echo "📁 前端檔案位於: frontend/dist"
echo ""
echo "💡 建議使用 Nginx 或其他 Web 服務器來服務前端檔案"
echo "📖 詳細部署說明請參考 DEPLOYMENT.md"

# 等待後端進程
wait $BACKEND_PID
