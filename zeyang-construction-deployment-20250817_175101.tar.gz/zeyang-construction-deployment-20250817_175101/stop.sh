#!/bin/bash

echo "🛑 停止澤暘建設專案..."

# 停止 PM2 進程
if command -v pm2 &> /dev/null; then
    pm2 stop zeyang-backend 2>/dev/null || true
    echo "✅ PM2 進程已停止"
fi

# 停止 Node.js 進程
pkill -f "node.*server.js" 2>/dev/null || true
echo "✅ Node.js 進程已停止"

echo "✅ 澤暘建設專案已停止"
